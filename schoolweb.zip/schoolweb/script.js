var navlinks = document.getElementById("navlinks");

    function showmenu() {
        navlinks.style.right = "0"
    }
    function hidemenu() {
        navlinks.style.right = "-200px"

    }



